public class Heap_easy_notComplete {
    public static void main(String[] args) {

    }

    //703. 数据流中的第K大元素
    public class KthLargest {

        public KthLargest(int k, int[] nums) {

        }

        public int add(int val) {
            return val;
        }
    }
}
